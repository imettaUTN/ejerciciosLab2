﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class Negocio
    {
        private PuestoAtencion caja;
        private Queue<Cliente> clientes ;
        private string nombre;

        private Negocio()
        {
            clientes = new Queue<Cliente>();
            this.caja = new PuestoAtencion(PuestoAtencion.Puesto.caja1);
        }
        public Negocio(string nombre) : this()
        {
            this.nombre = nombre;
           
        }

        public  Cliente Cliente
        {
            get
            {
                return clientes.Dequeue();
            }
            set
            {
                //clientes.Enqueue(value);
                _ = this + value;

            }

        }

        public int ClientesPendientes
        {
            get
            {
                return clientes.Count();
            }
        }
        public static bool operator ==(Negocio n1, Cliente cli)
        {
           if(n1 is null || cli is null)
            {
                return false;
            }
           foreach(Cliente c in n1.clientes)
            {
                if(c == cli)
                { return true; }
            }

             return  false;
        }

        public static bool operator !=(Negocio n1, Cliente cli)
        {
            if (n1 == null || cli == null)
            {
                return false;
            }
            return !(n1 == cli);
        }

        public static bool operator +(Negocio n1, Cliente cli)
        {
            if (n1 == null || cli == null)
            {
                return false;
            }
            if (n1 != cli)
            {
                n1.clientes.Enqueue(cli);
                return true;
            }
            return false;
        }
        public static bool operator ~(Negocio n1)
        {
            if(n1 == null)
            {
                return false;
            }
            if(n1.ClientesPendientes <=0)
            {
                return false;
            }
            return n1.caja.Atender(n1.Cliente);
        }


    }
}
