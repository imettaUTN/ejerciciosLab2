﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace Business
{
    class PuestoAtencion
    {
        private static int numeroActual;
        private Puesto puesto;
        private PuestoAtencion()
        {
            numeroActual = 0;
        }
        public PuestoAtencion(Puesto puesto) : this()
        {
            this.puesto = puesto;
        }

        public enum Puesto
        {
            caja1,
            caja2
        }

        public static  int NumeroActual
        {
            get
            {
                numeroActual ++;
                return numeroActual ;
            }
        }

        public bool Atender(Cliente cli)
        {
            if(cli == null)
            {
                return false;
            }
            Thread.Sleep(100);
            return true;
        }
    }
}
