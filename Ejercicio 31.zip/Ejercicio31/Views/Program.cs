﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business;
namespace Views
{
    class Program
    {
        static void Main(string[] args)
        {
            Cliente c1 = new Cliente(1, "juan");
            Cliente c2 = new Cliente(2, "juan 2");
            Cliente c3 = new Cliente(3, "juan 3");
            Cliente c4 = new Cliente(4, "juan 4");
            Negocio n1 = new Negocio("Negocio 1");
            if( n1 + c1)
            {
                Console.WriteLine("Agrego cliente : {0} \n", c1.Nombre);
            }
            if (n1 + c2)
            {
                Console.WriteLine("Agrego cliente : {0} \n", c2.Nombre);
            }
            if (n1 + c3)
            {
                Console.WriteLine("Agrego cliente : {0} \n", c3.Nombre);
            }
            if (n1 + c4)
            {
                Console.WriteLine("Agrego cliente : {0} \n", c4.Nombre);
            }

            if(~ n1)
            {
                Console.WriteLine("Atendo a un cliente , quedan {0} por atender \n ", n1.ClientesPendientes);

            }
            if (~n1)
            {
                Console.WriteLine("Atendo a un cliente , quedan {0} por atender \n", n1.ClientesPendientes);

            }
            if (~n1)
            {
                Console.WriteLine("Atendo a un cliente , quedan {0} por atender \n", n1.ClientesPendientes);

            }
            if (~n1)
            {
                Console.WriteLine("Atendo a un cliente , quedan {0} por atender \n", n1.ClientesPendientes);

            }
            //no deberia atenderlo porque no hay mas en la cola
            if (~n1)
            {
                Console.WriteLine("Atendo a un cliente , quedan {0} por atender \n", n1.ClientesPendientes);

            }

            Console.ReadKey();
        }
    }
}
