﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio
{
    class Libro
    {
        List<String> paginas = new List<string>();
        public string this[int i]
        {
            get { 
                if( i >= 0 && i >paginas.Count )
                {
                    return "";
                }
                return paginas[i]; 
            }
            set { 
                if(i > 0 && paginas.Contains(value) )
                {
                    paginas[i] = value;
                }
                else
                {
                    paginas.Add(value);
                }
            }
        }
    }
}
