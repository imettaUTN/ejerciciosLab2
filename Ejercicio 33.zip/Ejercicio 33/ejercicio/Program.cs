﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio
{
    class Program
    {
        static void Main(string[] args)
        {
            Libro lib = new Libro();
            lib[0] = "pagina 1";
            lib[2] = "pagina 2";
            lib[3] = "pagina 3";
            Console.WriteLine("pagina : {0} \n" , lib[0]);
            Console.WriteLine("pagina : {0} \n" , lib[4]);
            lib[0] = "pagina 4";
            Console.WriteLine("pagina : \n" + lib[3]);
            Console.ReadKey();
        }
    }
}
