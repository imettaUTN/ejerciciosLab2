﻿
namespace Views
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RchPalabras = new System.Windows.Forms.RichTextBox();
            this.BtCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RchPalabras
            // 
            this.RchPalabras.Location = new System.Drawing.Point(13, 38);
            this.RchPalabras.Name = "RchPalabras";
            this.RchPalabras.Size = new System.Drawing.Size(763, 326);
            this.RchPalabras.TabIndex = 0;
            this.RchPalabras.Text = "";
            // 
            // BtCalcular
            // 
            this.BtCalcular.Location = new System.Drawing.Point(547, 370);
            this.BtCalcular.Name = "BtCalcular";
            this.BtCalcular.Size = new System.Drawing.Size(147, 34);
            this.BtCalcular.TabIndex = 1;
            this.BtCalcular.Text = "Calcular";
            this.BtCalcular.UseVisualStyleBackColor = true;
            this.BtCalcular.Click += new System.EventHandler(this.BtCalcular_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtCalcular);
            this.Controls.Add(this.RchPalabras);
            this.Name = "Form1";
            this.Text = "Contador Palabras";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox RchPalabras;
        private System.Windows.Forms.Button BtCalcular;
    }
}

