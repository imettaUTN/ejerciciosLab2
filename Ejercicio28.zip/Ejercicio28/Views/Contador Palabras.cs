﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Views
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        static int Comparar(ValoresDiccionario a, ValoresDiccionario b)
        {
            return b.ValueDictionary - a.ValueDictionary;
        }
        private void BtCalcular_Click(object sender, EventArgs e)
        {
           Dictionary<string, int> diccionario = new Dictionary<string, int>();
           List<ValoresDiccionario> lista = new List<ValoresDiccionario>();

           foreach (string palabra in  RchPalabras.Text.Split(" "))
           {
                int cant;

                if (diccionario.ContainsKey(palabra))
                {
                    diccionario.TryGetValue(palabra, out cant);
                    diccionario[palabra] = ++cant;
                }
                else
                {
                    diccionario.Add(palabra, 1);
                }
           }

           // no tiene sentido ordenar un diccionario, asi paso el diccionario a una lista para luego ordenarlo
           foreach(string key in diccionario.Keys)
           {
                lista.Add(new ValoresDiccionario(key, diccionario[key]));
           }
            diccionario.Clear();
            
            lista.Sort(Comparar);


            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Las primeras 3 palabras mas usadas son :");
            for ( int i =0; i< 3; i++)
            {
                sb.AppendLine("Palabra " + i+1+": " + lista[i].KeyDictionary);
            }

            MessageBox.Show(sb.ToString());
        }
    }

    internal class ValoresDiccionario
    {
        private string key;
        private int value;
        public ValoresDiccionario(string key, int value)
        {
            KeyDictionary = key;
            ValueDictionary = value;
        }

        public string KeyDictionary
        {
            get { return this.key; }
            set { this.key = value; }
        }

        public int ValueDictionary
        {
            get { return this.value; }
            set { this.value = value; }
        }
        

    }
}
