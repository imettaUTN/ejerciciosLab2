﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    
    public class Baraja
    {
        private Carta[] mazo = new Carta[48];

        public Baraja()
        {
            for(int valor =1, fila =0; valor<= 12;valor++)
            {
                
                for(int palo =0; palo <4; palo ++, fila++)
                {
                    mazo[fila] = new Carta((Carta.Valor)valor, (Carta.Palo)palo);
                }
            }     
           

        }

        public string MostrarBaraja()
        {
            StringBuilder sb = new StringBuilder();
            foreach(Carta c in mazo)
            {
                sb.AppendLine(c.ObtenerNombre());
            }
            return sb.ToString();
        }

        public Carta ObtenerUltimaCarta()
        {
            Carta c;
            if (mazo.Length == 0)
            {
                return null;
            }
            c = mazo[mazo.Length -1];
            Array.Resize(ref mazo, mazo.Length -1);
            return c;
        }
        public void AgregarCarta(Carta c)
        {
            if(mazo.Length <48)
            {
                Array.Resize(ref mazo, mazo.Length + 1);
                mazo[mazo.Length -1] = c;
            }
        }

        public Carta[] MezclarCartas()
        {
            int cantidad = this.mazo.Length;
            int az;
            Carta tmp;

            for( int k = cantidad -1; k>= 0; k--)
            {
                az = new Random().Next(0, k);
                tmp = mazo[az];
                mazo[az] = mazo[k];
                mazo[k] = tmp;
            }
            return mazo;
        }


        public void OrdenarMazo()
        {
            int i = 1;
            bool ordenado = false;
            while (i < mazo.Length && ordenado == false)
            {
                i = i + 1;
                ordenado = true;
                for(int  j = 0; j < mazo.Length -1; j++)
                {                    
                    if(Carta.CompararCartas(mazo[j],mazo[j+1]) > 0)
                    {
                        ordenado = false;
                        Carta aux = mazo[j];
                        mazo[j] = mazo[j + 1];
                        mazo[j + 1] = aux;
                    }
                }
            }
        }

    }
}
