﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class Baraja_Colecciones
    {
        private List<Carta> mazo = new List<Carta>();

        public Baraja_Colecciones()
        {


            for (int valor = 1, fila = 0; valor <= 12; valor++)
            {

                for (int palo = 0; palo < 4; palo++, fila++)
                {
                    mazo.Add(new Carta((Carta.Valor)valor, (Carta.Palo)palo));
                }
            }


        }

        public string MostrarBaraja()
        {
            StringBuilder sb = new StringBuilder();
            foreach (Carta c in mazo)
            {
                sb.AppendLine(c.ObtenerNombre());
            }
            return sb.ToString();
        }

        public Carta ObtenerUltimaCarta()
        {
            Carta c;
            if (mazo.Count() == 0)
            {
                return null;
            }
            c = mazo.LastOrDefault();
            mazo.Remove(c);
            return c;
        }
        public bool AgregarCarta(Carta c)
        {
            if(mazo.Count < 48 )
            {
                mazo.Add(c);
                return true;

            }
            return false;
        }

        public List<Carta> MezclarCartas()
        {
            int cantidad = this.mazo.Count();
            int az;
            Carta tmp;

            for (int k = cantidad - 1; k >= 0; k--)
            {
                az = new Random().Next(0, k);
                tmp = mazo[az];
                mazo[az] = mazo[k];
                mazo[k] = tmp;
            }
            return mazo;
        }


        public void OrdenarMazo()
        {
            mazo.Sort(Carta.CompararCartas);

        }
    }
}
