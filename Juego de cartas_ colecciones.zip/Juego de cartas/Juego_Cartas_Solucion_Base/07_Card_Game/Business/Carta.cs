﻿namespace Business
{
    public class Carta
    {
        public enum Palo
        {
            Copas,
            Oros,
            Bastos,
            Espadas
        }

        public enum Valor
        {
            As = 1,
            Dos,
            Tres,
            Cuatro,
            Cinco,
            Seis,
            Siete,
            Ocho,
            Nueve,
            Sota = 10,
            Caballo,
            Rey
        }

        private Valor valor;
        private Palo palo;

        public Carta(Valor valor, Palo palo)
        {
            this.valor = valor;
            this.palo = palo;
        }

        public string ObtenerNombre()
        {
            return $"{this.valor} de {this.palo}";
        }
        public static int CompararCartas(Carta c1, Carta c2)
        {
            if(c1.palo.Equals(c2.palo))
            {
              return c1.valor - c2.valor;               

            }
            return c1.palo - c2.palo;
        }

       
    }
}
