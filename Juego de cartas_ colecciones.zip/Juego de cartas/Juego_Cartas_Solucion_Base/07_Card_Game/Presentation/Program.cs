﻿using Business;
using System;
using Business;
namespace Presentation
{
    class Program
    {
        static void Main(string[] args)
        {
            Baraja_Colecciones cartas = new Baraja_Colecciones();
            Console.WriteLine(cartas.MostrarBaraja());
            Console.WriteLine("Ultima carta");
            Console.WriteLine(cartas.ObtenerUltimaCarta().ObtenerNombre());
            Console.WriteLine("Agrego  carta : " + (new Carta(Carta.Valor.Caballo, Carta.Palo.Copas).ObtenerNombre()));
            cartas.AgregarCarta(new Carta(Carta.Valor.Caballo, Carta.Palo.Copas));
            Console.WriteLine("mezclo cartas");
            cartas.MezclarCartas();
            Console.WriteLine(cartas.MostrarBaraja());
            Console.WriteLine("ordeno cartas");
            cartas.OrdenarMazo();
            Console.WriteLine(cartas.MostrarBaraja());
            /*Baraja cartas = new Baraja();
            Console.WriteLine(cartas.MostrarBaraja());
            Console.WriteLine("Ultima carta");
            Console.WriteLine(cartas.ObtenerUltimaCarta().ObtenerNombre());
            Console.WriteLine("Agrego  carta : " + (new Carta(Carta.Valor.Caballo, Carta.Palo.Copas).ObtenerNombre()));
            cartas.AgregarCarta(new Carta(Carta.Valor.Caballo, Carta.Palo.Copas));
            Console.WriteLine("mezclo cartas");
            cartas.MezclarCartas();
            Console.WriteLine(cartas.MostrarBaraja());
            Console.WriteLine("ordeno cartas");
            cartas.OrdenarMazo();
            Console.WriteLine(cartas.MostrarBaraja());*/
            Console.ReadKey();
        }
    }
}
